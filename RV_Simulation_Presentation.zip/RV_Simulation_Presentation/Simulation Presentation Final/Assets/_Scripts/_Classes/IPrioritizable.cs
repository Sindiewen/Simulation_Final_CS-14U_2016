﻿public interface IPrioritizable
{
	int Priority { get; }
}
